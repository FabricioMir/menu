import 'package:flutter/material.dart';
//import 'package:comidas_tip/model/comida.dart';
import 'package:flutter/cupertino.dart';

void main() {
  runApp(MaterialApp(
      home:MenuPage()));
}

class MenuPage extends StatefulWidget {
  @override
  _MenuPageState createState() => _MenuPageState();
}
//class IconHeader extends StatefulWidget {
//  @override
//  _IconHeader createState() => _IconHeader();
//}
class _MenuPageState extends State<MenuPage> {


  final items =<comida>[
    comida('Esta receta de pan de muerto es un dulce tipico de Mexico que suele elaborarse los primeros días de noviembre para celebrar el día de muertos.', 'Pan de muerto', 10.00),
    comida('Se cree que fueron las madres agustinas del convento de "Santa Monica", en Puebla, quienes en 1821 crearon los chiles en nogada en honor a Agustin de Iturbide', 'Chile en Nogada', 50.00),
    comida('Laminas de cerdo frito enchilado y fileteado en trompo con piña, cebolla, cilantro y salsa al gusto.', 'Taco de pastor', 10.00),
    comida('Pizza con queso mozarella, champiñones, pimiento y aceitunas.', 'Pizza', 120.00),
    comida('Churros, con una corteza crujiente y centro suave.', 'Churros', 13.00),
    comida('Gorditas mexicanas tipicas por su sabor e increible mezcla de la masa de maíz y chicharron.', 'Gorditas', 13.00),
    comida('Tortilla rellena de pollo bañada en salsa roja o verde.', 'Enchiladas', 25.00),
    comida('Las rajas de chile poblano son una excelente opción para aquellos que quieren dejar descansar la carne.', 'Rajas de chile', 20.00),
    comida('Parecidos a los sopes, pero que en tamaño simula al huarache o chancla que usamos en los pies, puede servirse con diferentes guisos.', 'Huaraches', 50.00),
    comida('Si vas a atreverte a algo mas picante, esta opcion mexicana de chiles jalapeños rellenos de queso envueltos en tocino.', 'Chiles jalapeños rellenos', 40.00),
    comida('Si te gustan los sabores dulces, tambien puedes probar el delicioso chocolate caliente para los dias frios.', 'Chocolate caliente', 12.00),
    comida('No hay mejor forma de acompañar un cafe o un chocolate con un rico pan de dulce tradicional.', 'Pan dulce', 10.00),
    comida('Tacos con carne de puerco: maciza, buche, cuero, oreja, panza, etc.', 'Tacos de carnitas', 17.00),
    comida('Bebida gasificada refrescante fria de diferentes sabores.', 'Refrescos', 15.00),
    comida('Si prefieres algo para despertarte o para los amantes del cafe, tenemos diferente variedad.', 'Café', 14.00),
  ];


  @override
    Widget build(BuildContext context){
    final size = MediaQuery.of(context).size;
    return SafeArea(
      child: Scaffold(
        body: Stack(
          children: [
            Container(
              margin: EdgeInsets.only(
                top:size.height*0.18,
              ),
              child: SafeArea(
                child: GridView.builder(
                  gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 1),
                  itemCount: 15,
                  itemBuilder: (BuildContext context, int i) {
                    return Card(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)
                      ),
                      child: Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.all(0.5),
                            child: Image(
                              image: NetworkImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6YZ1jRARHHZ4cscsYF5PX_3VAEZQGIu-6xroKI8-8szEiiTs&s')
                            ),
                          ),
                          Text('${items[i].namecomida}'.toUpperCase(),
                            style: TextStyle(
                              fontSize: 30.0,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text('${items[i].descriptioncomida}',
                            style: TextStyle(
                            fontSize: 20.0,
                            fontWeight: FontWeight.w600,
                          ),
                          ),
                          Text('\$${items[i].pricecomida}',
                            style: TextStyle(
                              fontSize: 30.0,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                      color: Colors.blue[180],
                      elevation: 10.0,
                    );
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//-------------------------------------------------------------------

class comida{
  final String namecomida;
  final String descriptioncomida;
  final double pricecomida;
  comida(this.descriptioncomida, this.namecomida, this.pricecomida);
}

//-----------------------------------------------------------------

class _IconHeader extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AppBar Demo'),
      ),
    );
  }
}

//----------------------------------------------------------------