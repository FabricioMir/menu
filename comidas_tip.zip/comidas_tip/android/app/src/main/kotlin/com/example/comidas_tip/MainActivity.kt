package com.example.comidas_tip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
